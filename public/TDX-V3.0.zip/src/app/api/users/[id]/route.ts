import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser, hasPermission, logAudit, jsonError, jsonOk } from "@/lib/server";

export const dynamic = "force-dynamic";

// PUT /api/users/[id] — edit user
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user || !hasPermission(user, "manage_users")) return jsonError("Unauthorized", 401);
  const { id } = await params;
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return jsonError("Invalid body"); }

  const existing = await db.user.findUnique({ where: { id } });
  if (!existing) return jsonError("Not found", 404);

  const data: Record<string, unknown> = {};
  if (typeof body.name === "string") data.name = body.name;
  if (typeof body.role === "string") data.role = body.role;
  if (typeof body.status === "string") data.status = body.status;
  if (typeof body.phone === "string") data.phone = body.phone;
  if (typeof body.title === "string") data.title = body.title;

  const updated = await db.user.update({ where: { id }, data });
  await logAudit({ user, action: "UPDATE", entity: "User", entityId: id, details: `Updated user ${existing.email}` });
  return jsonOk({ user: updated });
}

// DELETE /api/users/[id] — soft delete (deactivate)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user || !hasPermission(user, "manage_users")) return jsonError("Unauthorized", 401);
  const { id } = await params;
  const existing = await db.user.findUnique({ where: { id } });
  if (!existing) return jsonError("Not found", 404);
  if (existing.id === user.id) return jsonError("Cannot deactivate yourself");

  await db.user.update({ where: { id }, data: { status: "Inactive" } });
  await logAudit({ user, action: "DEACTIVATE", entity: "User", entityId: id, details: `Deactivated user ${existing.email}` });
  return jsonOk({ ok: true });
}
