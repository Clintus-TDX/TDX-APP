"use client";

import { useAuth } from "@/context/auth-context";
import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import {
  STATUSES,
  PAY_RATE_TYPES_PRIMARY,
  PAY_RATE_TYPES_SECONDARY,
  ATTACHMENT_LIMITS,
  getAllowedExtensions,
} from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  X,
  Save,
  Loader2,
  Upload,
  Trash2,
  MessageSquarePlus,
  Image as ImageIcon,
  FileText,
  Download,
  CheckCircle,
} from "lucide-react";
import Image from "next/image";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface AuditBoardProps {
  workOrderId: string;
  onClose: () => void;
  onSaved: () => void;
}

interface Note {
  id: string;
  text: string;
  author: string;
  timestamp: string;
}

interface Attachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  order: number;
  filePath: string;
}

interface WorkOrderFull {
  id: string;
  ticketId: string;
  clientId: string | null;
  clientName: string;
  jobPlatformId: string | null;
  jobPlatformName: string;
  status: string;
  customerReferences: string;
  siteLocation: string;
  streetAddress: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  salesOrder: string;
  etaDlaDate: string | null;
  workedStartTime: string | null;
  workedEndTime: string | null;
  payRatePrimary: string;
  payRateSecondary: string;
  fieldEngineerId: string | null;
  fieldEngineerName: string;
  hours: number;
  expenses: number;
  incurredExpenses: number;
  hourlyRate: number;
  comments: string;
  notes: string;
  dateCreated: string;
  dateModified: string;
  attachments: Attachment[];
  client?: { id: string; name: string; address?: string; contactName?: string; contactEmail?: string };
  fieldEngineer?: { id: string; name: string; email?: string; phone?: string };
}

export function AuditBoard({ workOrderId, onClose, onSaved }: AuditBoardProps) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const panelRef = useRef<HTMLDivElement>(null);

  // Toast state
  const [toast, setToast] = useState<string | null>(null);
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }, []);

  // Fetch work order
  const { data, isLoading } = useQuery<{ workOrder: WorkOrderFull }>({
    queryKey: ["workorder", workOrderId],
    queryFn: () => fetch(`/api/workorders/${workOrderId}`).then(r => r.json()),
    enabled: !!workOrderId,
  });

  const wo = data?.workOrder;

  // Edit state
  const [form, setForm] = useState<Record<string, unknown>>({});
  const [notes, setNotes] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState("");
  const [deleteAttId, setDeleteAttId] = useState<string | null>(null);
  const [viewAttId, setViewAttId] = useState<string | null>(null);

  // Fetch lookups
  const { data: clientsData } = useQuery({ queryKey: ["clients"], queryFn: () => fetch("/api/clients").then(r => r.json()) });
  const { data: engineersData } = useQuery({ queryKey: ["engineers"], queryFn: () => fetch("/api/engineers").then(r => r.json()) });
  const { data: platformsData } = useQuery({ queryKey: ["platforms"], queryFn: () => fetch("/api/platforms").then(r => r.json()) });

  const clients = (clientsData?.clients as { id: string; name: string }[]) || [];
  const engineers = (engineersData?.engineers as { id: string; name: string }[]) || [];
  const platforms = (platformsData?.platforms as { id: string; name: string }[]) || [];

  // Sync form when wo loads
  useEffect(() => {
    if (wo) {
      const newForm = {
        ticketId: wo.ticketId,
        clientId: wo.clientId || "",
        clientName: wo.clientName,
        jobPlatformId: wo.jobPlatformId || "",
        jobPlatformName: wo.jobPlatformName,
        status: wo.status,
        customerReferences: wo.customerReferences,
        siteLocation: wo.siteLocation,
        streetAddress: wo.streetAddress || "",
        city: wo.city || "",
        state: wo.state || "",
        zipCode: wo.zipCode || "",
        country: wo.country || "USA",
        salesOrder: wo.salesOrder || "",
        etaDlaDate: wo.etaDlaDate ? new Date(wo.etaDlaDate).toISOString().slice(0, 16) : "",
        workedStartTime: wo.workedStartTime ? new Date(wo.workedStartTime).toISOString().slice(0, 16) : "",
        workedEndTime: wo.workedEndTime ? new Date(wo.workedEndTime).toISOString().slice(0, 16) : "",
        payRatePrimary: wo.payRatePrimary,
        payRateSecondary: wo.payRateSecondary,
        fieldEngineerId: wo.fieldEngineerId || "",
        fieldEngineerName: wo.fieldEngineerName,
        hours: wo.hours,
        expenses: wo.expenses,
        incurredExpenses: wo.incurredExpenses,
        hourlyRate: wo.hourlyRate,
        comments: wo.comments,
      };
      queueMicrotask(() => {
        setForm(newForm);
        try { setNotes(typeof wo.notes === "string" ? JSON.parse(wo.notes) : []); } catch { /* use existing notes */ }
      });
    }
  }, [wo]);

  const updateForm = (key: string, value: unknown) => setForm(prev => ({ ...prev, [key]: value }));

  // Save mutation
  const saveMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/workorders/${workOrderId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to save");
      }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["workorder", workOrderId] }); onSaved(); showToast("Ticket saved successfully"); },
    onError: (err: Error) => { showToast(`Error: ${err.message}`); },
  });

  // Add note mutation
  const noteMut = useMutation({
    mutationFn: async () => {
      if (!newNote.trim()) return;
      await fetch(`/api/workorders/${workOrderId}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: newNote.trim() }),
      });
    },
    onSuccess: () => {
      setNewNote("");
      qc.invalidateQueries({ queryKey: ["workorder", workOrderId] });
      showToast("Note added successfully");
    },
    onError: () => { showToast("Failed to add note"); },
  });

  // Delete attachment
  const deleteAttMut = useMutation({
    mutationFn: async (id: string) => {
      await fetch(`/api/attachments/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      setDeleteAttId(null);
      qc.invalidateQueries({ queryKey: ["workorder", workOrderId] });
      showToast("Attachment deleted");
    },
    onError: () => { showToast("Failed to delete attachment"); },
  });

  // Upload attachment
  const uploadMut = useMutation({
    mutationFn: async (files: File[]) => {
      const formData = new FormData();
      formData.append("workOrderId", workOrderId);
      for (const file of files) formData.append("files", file);
      await fetch("/api/attachments", { method: "POST", body: formData });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["workorder", workOrderId] }); showToast("Attachment uploaded"); },
    onError: () => { showToast("Failed to upload attachment"); },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) uploadMut.mutate(files);
  };

  const formatDate = (d: string) => {
    try { return new Date(d).toLocaleString("en-US", { month: "short", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }); } catch { return d; }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
  };

  const isImage = (type: string) => type.startsWith("image/");

  // View attachment details
  const viewAtt = wo?.attachments.find(a => a.id === viewAttId);

  return (
    <>
      {/* Toast notification */}
      {toast && (
        <div className="fixed top-16 right-4 z-[60] bg-primary text-primary-foreground px-4 py-2.5 rounded-lg shadow-lg text-sm flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle className="h-4 w-4 shrink-0" />
          {toast}
          <button onClick={() => setToast(null)} className="ml-1 hover:opacity-70"><X className="h-3 w-3" /></button>
        </div>
      )}

      {/* Slide-out panel */}
      <div className="fixed inset-0 z-50 flex justify-end">
        {/* Backdrop */}
        <div className="absolute inset-0 bg-black/30" onClick={onClose} />

        {/* Panel */}
        <div
          ref={panelRef}
          className="relative w-full max-w-xl bg-card border-l border-border shadow-2xl flex flex-col animate-in slide-in-from-right duration-300"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div>
              <h3 className="font-semibold text-sm">Edit Ticket</h3>
              <p className="text-xs text-muted-foreground">{wo?.ticketId}</p>
            </div>
            <div className="flex items-center gap-1">
              <Button size="sm" onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
                <Save className="h-4 w-4 mr-1" />
                Save
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="flex-1 flex items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : wo ? (
            <div className="flex-1 overflow-y-auto overflow-x-hidden custom-scroll">
              <div className="p-4 space-y-4">
                {/* Status */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Status</Label>
                  <Select value={String(form.status)} onValueChange={v => updateForm("status", v)}>
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUSES.map(s => (
                        <SelectItem key={s.key} value={s.key}>
                          <span className="flex items-center gap-2">
                            <span className="h-3 w-3 rounded-sm inline-block border border-black/10" style={{ backgroundColor: s.bg }} />
                            {s.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                {/* Ticket ID */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Ticket ID</Label>
                  <Input value={String(form.ticketId || "")} onChange={e => updateForm("ticketId", e.target.value)} className="h-9" />
                </div>

                {/* Client */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Client</Label>
                  <Select value={String(form.clientId || "")} onValueChange={v => {
                    updateForm("clientId", v);
                    updateForm("clientName", clients.find(c => c.id === v)?.name || "");
                  }}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {clients.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {wo.client?.address && <p className="text-[11px] text-muted-foreground">{wo.client.address}</p>}
                </div>

                {/* Job Platform */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Job Platform</Label>
                  <Select value={String(form.jobPlatformId || "")} onValueChange={v => {
                    updateForm("jobPlatformId", v);
                    updateForm("jobPlatformName", platforms.find(p => p.id === v)?.name || "");
                  }}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {platforms.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                {/* Field Engineer */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Field Engineer</Label>
                  <Select value={String(form.fieldEngineerId || "")} onValueChange={v => {
                    updateForm("fieldEngineerId", v);
                    updateForm("fieldEngineerName", engineers.find(e => e.id === v)?.name || "");
                  }}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {engineers.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {wo.fieldEngineer?.email && <p className="text-[11px] text-muted-foreground">{wo.fieldEngineer.email}</p>}
                </div>

                {/* Site Location */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Site / Location</Label>
                  <Input value={String(form.siteLocation || "")} onChange={e => updateForm("siteLocation", e.target.value)} className="h-9" />
                </div>

                {/* Street Address */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Street Address</Label>
                  <Input value={String(form.streetAddress || "")} onChange={e => updateForm("streetAddress", e.target.value)} className="h-9" />
                </div>

                {/* City / State / Zip */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">City</Label>
                    <Input value={String(form.city || "")} onChange={e => updateForm("city", e.target.value)} className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">State</Label>
                    <Input value={String(form.state || "")} onChange={e => updateForm("state", e.target.value)} className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Zip Code</Label>
                    <Input value={String(form.zipCode || "")} onChange={e => updateForm("zipCode", e.target.value)} className="h-9" />
                  </div>
                </div>

                {/* Country */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Country</Label>
                  <Input value={String(form.country || "USA")} onChange={e => updateForm("country", e.target.value)} className="h-9" />
                </div>

                {/* Sales Order / Reference */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Sales Order / Reference</Label>
                  <Input value={String(form.salesOrder || "")} onChange={e => updateForm("salesOrder", e.target.value)} className="h-9" />
                </div>

                {/* ETA / DLA Date */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">ETA / DLA Date (Actual Pickup)</Label>
                  <Input type="datetime-local" value={String(form.etaDlaDate || "")} onChange={e => updateForm("etaDlaDate", e.target.value)} className="h-9" />
                </div>

                {/* Work Start / End Time */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Work Start Time</Label>
                    <Input type="datetime-local" value={String(form.workedStartTime || "")} onChange={e => updateForm("workedStartTime", e.target.value)} className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Work End Time</Label>
                    <Input type="datetime-local" value={String(form.workedEndTime || "")} onChange={e => updateForm("workedEndTime", e.target.value)} className="h-9" />
                  </div>
                </div>

                <Separator />

                {/* Pay Rates */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Pay Rate (Primary)</Label>
                    <Select value={String(form.payRatePrimary || "")} onValueChange={v => updateForm("payRatePrimary", v)}>
                      <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent>
                        {PAY_RATE_TYPES_PRIMARY.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Pay Rate (Secondary)</Label>
                    <Select value={String(form.payRateSecondary || "")} onValueChange={v => updateForm("payRateSecondary", v)}>
                      <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent>
                        {PAY_RATE_TYPES_SECONDARY.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Financial fields */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Hours</Label>
                    <Input type="number" step="0.25" value={String(form.hours ?? "")} onChange={e => updateForm("hours", parseFloat(e.target.value) || 0)} className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Hourly Rate ($)</Label>
                    <Input type="number" step="0.01" value={String(form.hourlyRate ?? "")} onChange={e => updateForm("hourlyRate", parseFloat(e.target.value) || 0)} className="h-9" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Expenses ($)</Label>
                    <Input type="number" step="0.01" value={String(form.expenses ?? "")} onChange={e => updateForm("expenses", parseFloat(e.target.value) || 0)} className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Incurred Expenses ($)</Label>
                    <Input type="number" step="0.01" value={String(form.incurredExpenses ?? "")} onChange={e => updateForm("incurredExpenses", parseFloat(e.target.value) || 0)} className="h-9" />
                  </div>
                </div>

                {/* Customer References */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Customer References</Label>
                  <Textarea value={String(form.customerReferences || "")} onChange={e => updateForm("customerReferences", e.target.value)} rows={2} className="text-sm" />
                </div>

                {/* Comments */}
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Comments</Label>
                  <Textarea value={String(form.comments || "")} onChange={e => updateForm("comments", e.target.value)} rows={3} className="text-sm" />
                </div>

                {/* Timestamps */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="text-xs">
                    <span className="text-muted-foreground">Created: </span>
                    {formatDate(wo.dateCreated)}
                  </div>
                  <div className="text-xs">
                    <span className="text-muted-foreground">Modified: </span>
                    {formatDate(wo.dateModified)}
                  </div>
                </div>

                <Separator />

                {/* Quick Notes */}
                <div className="space-y-2">
                  <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                    <MessageSquarePlus className="h-3.5 w-3.5" />
                    Quick Notes
                  </Label>
                  <div className="space-y-1 max-h-48 overflow-y-auto custom-scroll">
                    {notes.length === 0 && <p className="text-xs text-muted-foreground italic">No notes yet.</p>}
                    {[...notes].reverse().map((note) => (
                      <div key={note.id} className="bg-muted/50 rounded-md p-2 text-xs space-y-0.5">
                        <p className="font-medium">{note.author}</p>
                        <p className="text-muted-foreground">{note.text}</p>
                        <p className="text-muted-foreground text-[10px]">{formatDate(note.timestamp)}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a note..."
                      value={newNote}
                      onChange={e => setNewNote(e.target.value)}
                      className="h-8 text-xs"
                      onKeyDown={e => e.key === "Enter" && noteMut.mutate()}
                    />
                    <Button size="sm" variant="outline" onClick={() => noteMut.mutate()} disabled={noteMut.isPending || !newNote.trim()}>
                      {noteMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquarePlus className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <Separator />

                {/* Attachments */}
                <div className="space-y-2">
                  <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                    <Upload className="h-3.5 w-3.5" />
                    Attachments ({wo.attachments?.length || 0}/{ATTACHMENT_LIMITS.maxFiles})
                  </Label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <label className="cursor-pointer">
                        <Upload className="h-3.5 w-3.5 mr-1" />
                        Upload
                        <input type="file" multiple className="hidden" accept={getAllowedExtensions().join(",")} onChange={handleFileSelect} />
                      </label>
                    </Button>
                    {uploadMut.isPending && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                  </div>
                  {/* Thumbnail grid */}
                  {wo.attachments && wo.attachments.length > 0 && (
                    <div className="grid grid-cols-3 gap-2">
                      {wo.attachments.map(att => (
                        <div key={att.id} className="group relative border border-border rounded-md overflow-hidden bg-muted/30 aspect-square flex items-center justify-center cursor-pointer" onClick={() => setViewAttId(att.id)}>
                          {isImage(att.fileType) ? (
                            <img src={`/api/attachments/${att.id}`} alt={att.fileName} className="w-full h-full object-cover" />
                          ) : (
                            <div className="text-center p-1">
                              <FileText className="h-6 w-6 mx-auto text-muted-foreground" />
                              <p className="text-[9px] truncate max-w-full">{att.fileName}</p>
                              <p className="text-[9px] text-muted-foreground">{formatSize(att.fileSize)}</p>
                            </div>
                          )}
                          <button
                            className="absolute top-0.5 right-0.5 bg-destructive text-destructive-foreground rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={e => { e.stopPropagation(); setDeleteAttId(att.id); }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* Delete attachment confirmation */}
      <AlertDialog open={!!deleteAttId} onOpenChange={o => !o && setDeleteAttId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Attachment</AlertDialogTitle>
            <AlertDialogDescription>Are you sure? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={() => deleteAttId && deleteAttMut.mutate(deleteAttId)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View attachment modal */}
      <Dialog open={!!viewAttId} onOpenChange={o => !o && setViewAttId(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{viewAtt?.fileName}</DialogTitle>
          </DialogHeader>
          {viewAtt && (
            <div className="flex flex-col items-center gap-4">
              {isImage(viewAtt.fileType) ? (
                <img src={`/api/attachments/${viewAtt.id}`} alt={viewAtt.fileName} className="max-h-[60vh] max-w-full object-contain rounded border" />
              ) : (
                <div className="text-center py-12">
                  <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <p className="text-sm text-muted-foreground">{viewAtt.fileName}</p>
                  <p className="text-xs text-muted-foreground">{formatSize(viewAtt.fileSize)}</p>
                  <Button variant="outline" size="sm" className="mt-4" asChild>
                    <a href={`/api/attachments/${viewAtt.id}`} download>
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </a>
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
