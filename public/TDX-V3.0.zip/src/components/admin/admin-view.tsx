"use client";

import { useState, useEffect } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { useTheme } from "@/context/theme-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2,
  Plus,
  Trash2,
  Edit3,
  Users,
  Shield,
  Palette,
  Bell,
  Database,
  RotateCcw,
  UserPlus,
  Ban,
  Landmark,
  CheckCircle,
  X,
} from "lucide-react";
import {
  COLOR_THEMES,
  PERMISSIONS,
  SYSTEM_ROLES,
  NOTIFICATION_TYPES,
  DEFAULT_NOTIFY_PREFS,
} from "@/lib/constants";
import type { ColorThemeKey } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function AdminView() {
  const { user } = useAuth();
  const { colorTheme, setColorTheme, darkMode, toggleDarkMode } = useTheme();
  const qc = useQueryClient();
  const [toast, setToast] = useState<string | null>(null);
  useEffect(() => { if (toast) setTimeout(() => setToast(null), 3000); }, [toast]);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);
  const [deleteRoleId, setDeleteRoleId] = useState<string | null>(null);
  const [addRoleOpen, setAddRoleOpen] = useState(false);
  const [editRoleId, setEditRoleId] = useState<string | null>(null);
  const [seedConfirm, setSeedConfirm] = useState(false);
  const [clearConfirm, setClearConfirm] = useState(false);
  const [seedSections, setSeedSections] = useState<Record<string, boolean>>({ clients: true, engineers: true, platforms: true, workOrders: true, invoices: true });
  const [clearSections, setClearSections] = useState<Record<string, boolean>>({ workOrders: true, invoices: true, payments: true, attachments: true });

  // Fetch users
  const { data: usersData, isLoading: usersLoading } = useQuery({
    queryKey: ["users-admin"],
    queryFn: () => fetch("/api/users").then(r => r.json()),
  });
  const users = (usersData?.users as { id: string; email: string; name: string; role: string; status: string; createdAt: string }[]) || [];

  // Fetch roles
  const { data: rolesData } = useQuery({
    queryKey: ["roles"],
    queryFn: () => fetch("/api/roles").then(r => r.json()),
  });
  const roles = (rolesData?.roles as { id: string; name: string; description: string; permissions: string; isSystem: boolean }[]) || [];

  // Delete user mutation
  const deleteUserMut = useMutation({
    mutationFn: async (id: string) => fetch(`/api/users/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["users-admin"] }); setDeleteUserId(null); setToast("User deactivated"); },
  });

  // Add user mutation
  const addUserMut = useMutation({
    mutationFn: async (data: { name: string; email: string; role: string }) => {
      const res = await fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
      return res.json();
    },
    onSuccess: () => { setAddUserOpen(false); qc.invalidateQueries({ queryKey: ["users-admin"] }); setToast("User added"); },
  });

  // Delete role mutation
  const deleteRoleMut = useMutation({
    mutationFn: async (id: string) => fetch(`/api/roles/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["roles"] }); setDeleteRoleId(null); setToast("Role deleted"); },
  });

  // Seed mutation
  const seedMut = useMutation({
    mutationFn: () => fetch("/api/admin/seed", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sections: seedSections }) }).then(r => r.json()),
    onSuccess: () => { setSeedConfirm(false); qc.invalidateQueries({ queryKey: ["users-admin"] }); qc.invalidateQueries({ queryKey: ["roles"] }); setToast("Database seeded"); },
  });

  // Clear mutation
  const clearMut = useMutation({
    mutationFn: () => fetch("/api/admin/clear", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sections: clearSections }) }).then(r => r.json()),
    onSuccess: () => { setClearConfirm(false); setToast("Data cleared"); },
  });

  const isSuperAdmin = user?.role === "Super Admin";

  return (
    <div className="space-y-4">
      {toast && (
        <div className="fixed top-16 right-4 z-50 bg-primary text-primary-foreground px-4 py-2.5 rounded-lg shadow-lg text-sm flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle className="h-4 w-4 shrink-0" />
          {toast}
          <button onClick={() => setToast(null)} className="ml-1 hover:opacity-70"><X className="h-3 w-3" /></button>
        </div>
      )}
      <h2 className="text-xl font-semibold flex items-center gap-2">
        <div className="h-6 w-1.5 rounded brand-gradient" />
        Admin & Settings
      </h2>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="users" className="gap-1"><Users className="h-4 w-4" />Users</TabsTrigger>
          <TabsTrigger value="roles" className="gap-1"><Shield className="h-4 w-4" />Roles</TabsTrigger>
          <TabsTrigger value="theme" className="gap-1"><Palette className="h-4 w-4" />Theme</TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1"><Bell className="h-4 w-4" />Notifications</TabsTrigger>
          <TabsTrigger value="quickbooks" className="gap-1"><Landmark className="h-4 w-4" />QuickBooks</TabsTrigger>
          {isSuperAdmin && (
            <TabsTrigger value="data" className="gap-1"><Database className="h-4 w-4" />Data</TabsTrigger>
          )}
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => setAddUserOpen(true)}>
              <UserPlus className="h-4 w-4 mr-1" /> Add User
            </Button>
          </div>
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="max-h-[500px] custom-scroll">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                      <TableHead className="text-xs font-semibold uppercase tracking-wider h-9 px-3">Name</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider h-9 px-3">Email</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider h-9 px-3">Role</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider h-9 px-3">Status</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider h-9 px-3 w-16">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usersLoading ? (
                      <TableRow><TableCell colSpan={5} className="h-20 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></TableCell></TableRow>
                    ) : users.length === 0 ? (
                      <TableRow><TableCell colSpan={5} className="h-20 text-center text-muted-foreground">No users found.</TableCell></TableRow>
                    ) : (
                      users.map(u => (
                        <TableRow key={u.id} className="hover:bg-muted/30">
                          <TableCell className="px-3 py-2 text-sm font-medium">{u.name}</TableCell>
                          <TableCell className="px-3 py-2 text-sm">{u.email}</TableCell>
                          <TableCell className="px-3 py-2">
                            <Badge variant="secondary" className="text-xs">{u.role}</Badge>
                          </TableCell>
                          <TableCell className="px-3 py-2">
                            <Badge variant={u.status === "Active" ? "default" : "outline"} className={cn("text-xs", u.status === "Active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" : "text-destructive")}>{u.status}</Badge>
                          </TableCell>
                          <TableCell className="px-3 py-2">
                            {u.status === "Active" ? (
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDeleteUserId(u.id)} title="Deactivate">
                                <Ban className="h-3.5 w-3.5" />
                              </Button>
                            ) : null}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Roles Tab */}
        <TabsContent value="roles" className="space-y-4">
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => setAddRoleOpen(true)}>
              <Plus className="h-4 w-4 mr-1" /> Create Custom Role
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map(role => {
              let perms: Record<string, boolean> = {};
              try { perms = JSON.parse(role.permissions); } catch { perms = {}; }
              return (
                <Card key={role.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-semibold">{role.name}</CardTitle>
                      <div className="flex gap-1 items-center">
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditRoleId(role.id)} title="Edit permissions">
                          <Edit3 className="h-3.5 w-3.5" />
                        </Button>
                        {!role.isSystem && (
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDeleteRoleId(role.id)}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        )}
                        {role.isSystem && <Badge variant="outline" className="text-[10px]">System</Badge>}
                      </div>
                    </div>
                    {role.description && <CardDescription className="text-xs">{role.description}</CardDescription>}
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex flex-wrap gap-1">
                      {PERMISSIONS.filter(p => perms[p.key]).map(p => (
                        <Badge key={p.key} variant="secondary" className="text-[10px]">{p.label}</Badge>
                      ))}
                    </div>
                    <div className="mt-2">
                      <span className="text-[10px] text-muted-foreground">
                        {PERMISSIONS.filter(p => perms[p.key]).length} of {PERMISSIONS.length} permissions
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Theme Tab */}
        <TabsContent value="theme" className="space-y-4">
          <div className="space-y-4">
            {/* Dark/Light Mode */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-semibold">Dark Mode</h4>
                    <p className="text-xs text-muted-foreground">Toggle between light and dark appearance</p>
                  </div>
                  <Switch checked={darkMode} onCheckedChange={() => toggleDarkMode()} />
                </div>
              </CardContent>
            </Card>

            {/* Color Theme Selector */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Color Theme</CardTitle>
                <CardDescription className="text-xs">Choose from 7 distinct color themes. Your selection persists across sessions.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {COLOR_THEMES.map(theme => (
                    <button
                      key={theme.key}
                      className={cn(
                        "flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all hover:shadow-md",
                        colorTheme === theme.key
                          ? "border-primary bg-primary/5 shadow-sm"
                          : "border-border hover:border-primary/30"
                      )}
                      onClick={() => setColorTheme(theme.key as ColorThemeKey)}
                    >
                      <div className="flex gap-1">
                        {theme.swatch.map((color, i) => (
                          <div key={i} className="h-6 w-6 rounded-full border border-black/10" style={{ backgroundColor: color }} />
                        ))}
                      </div>
                      <span className="text-xs font-medium">{theme.label}</span>
                      <span className="text-[10px] text-muted-foreground">{theme.description}</span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Notification Preferences</CardTitle>
              <CardDescription className="text-xs">Configure which notifications you receive via email and in-app.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {NOTIFICATION_TYPES.map(type => (
                  <div key={type.key} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                    <span className="text-sm">{type.label}</span>
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-1.5 text-xs">
                        <Checkbox defaultChecked />
                        <span className="text-muted-foreground">Email</span>
                      </label>
                      <label className="flex items-center gap-1.5 text-xs">
                        <Checkbox defaultChecked />
                        <span className="text-muted-foreground">In-App</span>
                      </label>
                    </div>
                  </div>
                ))}
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-semibold">Quiet Hours</h4>
                    <p className="text-xs text-muted-foreground">Suppress notifications during specified hours.</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Label className="text-xs">From</Label>
                  <Input type="time" defaultValue="18:00" className="w-28 h-8 text-xs" />
                  <Label className="text-xs">To</Label>
                  <Input type="time" defaultValue="08:00" className="w-28 h-8 text-xs" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* QuickBooks Tab */}
        <TabsContent value="quickbooks" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">QuickBooks Integration</CardTitle>
              <CardDescription className="text-xs">Connect to QuickBooks Online for syncing invoices, payments, and financial reports.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <Landmark className="h-5 w-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">QuickBooks Online</p>
                    <p className="text-xs text-muted-foreground">Sync invoices, payments & financial reports</p>
                  </div>
                </div>
                <Button size="sm" onClick={() => window.open("/?tab=accounts", "_self")}>
                  Open Accounts
                </Button>
              </div>
              <Separator />
              <div className="text-xs text-muted-foreground space-y-1">
                <p>• Connect via OAuth 2.0 to sync data between Techadox and QuickBooks</p>
                <p>• Push invoices and payments to QuickBooks automatically</p>
                <p>• Pull customers, invoices, and payments from QuickBooks</p>
                <p>• View Profit & Loss, Balance Sheet, and AR Aging reports</p>
                <p>• View sync history and logs in the Accounts tab</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Tab (Super Admin Only) */}
        {isSuperAdmin && (
          <TabsContent value="data" className="space-y-4">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-semibold flex items-center gap-2">
                      <RotateCcw className="h-4 w-4" /> Seed Demo Data
                    </h4>
                    <p className="text-xs text-muted-foreground">Populate the database with sample data for selected sections.</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setSeedConfirm(true)}>
                    Seed Data
                  </Button>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-2 mt-1">
                  {Object.entries(seedSections).map(([key, checked]) => (
                    <label key={key} className="flex items-center gap-2 text-xs cursor-pointer">
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(v) => setSeedSections((prev) => ({ ...prev, [key]: !!v }))}
                      />
                      <span className="capitalize font-medium">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                    </label>
                  ))}
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-semibold flex items-center gap-2 text-destructive">
                      <Trash2 className="h-4 w-4" /> Clear Data
                    </h4>
                    <p className="text-xs text-muted-foreground">Delete data from selected sections. Users are preserved.</p>
                  </div>
                  <Button size="sm" variant="destructive" onClick={() => setClearConfirm(true)}>
                    Clear Data
                  </Button>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-2 mt-1">
                  {Object.entries(clearSections).map(([key, checked]) => (
                    <label key={key} className="flex items-center gap-2 text-xs cursor-pointer">
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(v) => setClearSections((prev) => ({ ...prev, [key]: !!v }))}
                      />
                      <span className="capitalize font-medium">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                    </label>
                  ))}
                </div>
                <p className="text-xs text-destructive/70 font-medium">⚠ Warning: Clearing data is permanent and cannot be undone.</p>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      {/* Add User Dialog */}
      <Dialog open={addUserOpen} onOpenChange={o => !o && setAddUserOpen(false)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add User</DialogTitle></DialogHeader>
          <AddUserForm onSubmit={() => { setAddUserOpen(false); qc.invalidateQueries({ queryKey: ["users-admin"] }); }} />
        </DialogContent>
      </Dialog>

      {/* Add Role Dialog */}
      <Dialog open={addRoleOpen || !!editRoleId} onOpenChange={o => { if (!o) { setAddRoleOpen(false); setEditRoleId(null); } }}>
        <DialogContent className="max-w-lg max-h-[80vh] flex flex-col">
          <DialogHeader><DialogTitle>{editRoleId ? "Edit Role" : "Create Custom Role"}</DialogTitle></DialogHeader>
          <RoleForm roleId={editRoleId} onClose={() => { setAddRoleOpen(false); setEditRoleId(null); qc.invalidateQueries({ queryKey: ["roles"] }); }} onSaved={() => { setToast(editRoleId ? "Role updated successfully" : "Role created successfully"); }} />
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation */}
      <AlertDialog open={!!deleteUserId} onOpenChange={o => !o && setDeleteUserId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Deactivate User</AlertDialogTitle><AlertDialogDescription>This will mark the user as inactive. They won&apos;t be able to sign in.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={() => deleteUserId && deleteUserMut.mutate(deleteUserId)}>Deactivate</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Role Confirmation */}
      <AlertDialog open={!!deleteRoleId} onOpenChange={o => !o && setDeleteRoleId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Delete Role</AlertDialogTitle><AlertDialogDescription>This cannot be undone. Users with this role will lose associated permissions.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={() => deleteRoleId && deleteRoleMut.mutate(deleteRoleId)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Seed Confirmation */}
      <AlertDialog open={seedConfirm} onOpenChange={setSeedConfirm}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Seed Demo Data?</AlertDialogTitle><AlertDialogDescription>This will create sample data for: {Object.keys(seedSections).filter(k => seedSections[k]).join(", ")}. Existing data will not be overwritten.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => seedMut.mutate()}>Seed Data</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Clear Confirmation */}
      <AlertDialog open={clearConfirm} onOpenChange={setClearConfirm}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Clear Selected Data?</AlertDialogTitle><AlertDialogDescription>This will permanently delete: {Object.keys(clearSections).filter(k => clearSections[k]).join(", ")}. Users and roles are preserved. This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={() => clearMut.mutate()}>Clear Data</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// Add User sub-form
function AddUserForm({ onSubmit }: { onSubmit: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Dispatcher");
  const [error, setError] = useState("");
  const mut = useMutation({
    mutationFn: (data: { name: string; email: string; role: string }) =>
      fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => { if (!r.ok) return r.json().then(d => { throw new Error(d.error); }); return r.json(); }),
    onSuccess: () => onSubmit(),
    onError: (e: Error) => setError(e.message),
  });

  return (
    <div className="space-y-3">
      <div className="space-y-1"><Label>Name</Label><Input value={name} onChange={e => setName(e.target.value)} /></div>
      <div className="space-y-1"><Label>Email</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>
      <div className="space-y-1">
        <Label>Role</Label>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{SYSTEM_ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onSubmit}>Cancel</Button>
        <Button onClick={() => mut.mutate({ name, email, role })} disabled={mut.isPending || !name || !email}>
          {mut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Plus className="h-4 w-4 mr-1" />}
          Add User
        </Button>
      </div>
    </div>
  );
}

// Role form sub-component
function RoleForm({ roleId, onClose, onSaved }: { roleId: string | null; onClose: () => void; onSaved: () => void }) {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["role", roleId],
    queryFn: () => fetch(`/api/roles/${roleId}`).then(r => r.json()),
    enabled: !!roleId,
  });
  const existingRole = roleId ? (data?.role as { name: string; permissions: string }) : null;

  const [name, setName] = useState(existingRole?.name || "");
  const [perms, setPerms] = useState<Record<string, boolean>>(() => {
    if (existingRole) { try { return JSON.parse(existingRole.permissions); } catch { return {}; } }
    return PERMISSIONS.reduce((a, p) => ({ ...a, [p.key]: false }), {});
  });

  const mut = useMutation({
    mutationFn: async () => {
      if (roleId) {
        return fetch(`/api/roles/${roleId}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, permissions: perms }) });
      } else {
        return fetch("/api/roles", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, permissions: perms }) });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["roles"] });
      onClose();
      onSaved();
    },
    onError: () => { /* Parent handles via setRoleToast */ },
  });

  return (
    <div className="space-y-4">
      <div className="space-y-1"><Label>Role Name</Label><Input value={name} onChange={e => setName(e.target.value)} /></div>
      <Separator />
      <div className="space-y-2">
        <Label className="text-xs font-semibold">Permissions</Label>
        <ScrollArea className="max-h-64 custom-scroll">
          <div className="space-y-2">
            {PERMISSIONS.map(p => (
              <label key={p.key} className="flex items-center gap-2 text-sm cursor-pointer py-0.5">
                <Checkbox checked={!!perms[p.key]} onCheckedChange={v => setPerms(prev => ({ ...prev, [p.key]: !!v }))} />
                {p.label}
              </label>
            ))}
          </div>
        </ScrollArea>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={() => mut.mutate()} disabled={mut.isPending || !name}>
          {mut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
          {roleId ? "Save" : "Create"}
        </Button>
      </DialogFooter>
    </div>
  );
}
